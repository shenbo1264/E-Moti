# 第十三组：模型服务不可用时停止

生产来源冻结 d3c55d2，旧基线 1e10b715。原数据 SHA 71ac9261b66a6b57f8a6c871b58d5148e2f51b98f892a6d8c14ca11503a09706 因 20 条卡缺少 Entry 必填 updated_at，在模型阶段前构造失败；原始错误保留于 thirteenth/retrieval。

经主任务授权，仅给版本未修订的 20 张卡增加 updated_at=created_at，并执行真实 Entry 构造及 validate；来源内容、问题、gold 均保持不变。修正版 SHA 0f1c5da71480a56e8783fdc9ffde8492e6130f5a7724abdc9eea17756a935b76，逐条 diff 保留于 memory-sealed-thirteenth-schemafixed/schema-correction.json。

修正版 none、lexical、bge_rrf 三路线本地检索完成。主任务通知另一实际调用已出现官方 API 402 后，立即中止本组运行；routed 工作进程未留下完整结果，layered 与真实生成均未完成。进程列表确认本组及 final-twelfth 无残留进程。未重试网络调用。

本组不能报告完整五路成绩或模型回答质量。实际生成状态为 not_run。routed 在中止前是否发出未落盘请求，当前记录不能确定；不将缺失记录表述为确定零调用。

后续恢复需要新输出目录保存续测，并继续使用 latest worktree 的 presentation 和 generation 工具，以包含最新表达复核行为。原始失败不得覆盖。
