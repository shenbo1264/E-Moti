# 第九、十组回归只读诊断

读取冻结 523150e 的原始 provider 请求与响应、交付 trace，并核对生产调用链。未修改 production、样本或评测结果；以下属于已见回归集分析，不作为新的密封泛化结论。

## 第九组

按需 6/8、分层 7/8。两路共同失败 v9_scent_q2：真实模型收到 s92 并正确给 planned_event / sufficient，原文完整引用苔铃签。最终却 unavailable，retries=3。`memory_index.finalize` 对 future 行仅检查单卡 metadata.time_basis == unix，没有复用档案 unix；s92 没有单卡标记，前置资格检查已继承档案 unix，最终检查没有继承。导致合法未来日期被误报并发来源变化。这是实际实现缺口。

按需额外失败 v9_scent_q3：真实 judge 虽引用 s93 身份证明和 s94 纸夹地点，却遗漏 subject_binding，最终 unresolved_or_ambiguous_entity。分层同一题给了 mention=她、antecedent=小穗、subject=person:陆姗、kind=alias 及原文来源，成功交付两张卡。两路差异可直接追溯为模型协议字段采样差异；一次下降不能直接归因为检索候选能力回退。当前仍缺稳定的来源身份组合处理。

## 第十组

两路均 5/8，但失败集合不同；没有把差异掩盖成同样的质量。

1. bake_q4 两路失败：模型给 sufficient / completed_event，quote 包含“我跟你…烤好了”；participants 放在 intent 上，宿主仅读取每条 evidence 的 participants，导致 source_shared_event 为 False。不是没召回，也不是这一句缺完成体标记。当前提示词说“共同经历证据额外给participants”但示例未明确嵌套层级，模型两次都作 intent 字段；属于协议和消费位置不一致。
2. tank_q4 两路失败：模型 planned_event / sufficient，完整引用“定在2026年9月23日晚上七点…尚未进行”；宿主 source_plan 识别词未包含“定在”，没有事件 metadata 的来源因此不能证明计划。这是宿主对原文计划语义的误拒。
3. routed bake_q3 失败：judge 选中亲属身份 m1 与约定计划 m4，显式 subject_binding 将阿栗绑定 person:cen_yue。进一步以独立单测确认实际根因在 `_alias_source_binding`：用 planned intent 检查身份凭证，身份卡本身不是计划，导致绑定失败并清空计划子问。最初将其推断为最终 subject 过滤不准确；最终 judgment 读取已清空 subjects。layered 同题没有 subject_binding，两个来源均交付。修复需将计划内容资格与身份凭证资格分离，并保留历史身份的查询时间语义。
4. layered tank_q1 失败：第二子问 80 升有正确原文，judge 额外输出 mention=他 的 alias binding，却没有可验证 antecedent；`_alias_source_binding` 找不到名为“他”的别名，清空该子问。routed 同题未输出这个无效 binding，单一事实主体推导成功。需要处理代词与当前同句已来源证明的主体联系，而不能将代词当别名或任意忽略绑定失败。

这些样本的相关来源 scope 为 companion，和第十一组 shared/companion 标注冲突不同。所有原始失败仍保留在 ninth-regression、tenth-regression JSON，修复后应另存结果，不能覆盖首评。
