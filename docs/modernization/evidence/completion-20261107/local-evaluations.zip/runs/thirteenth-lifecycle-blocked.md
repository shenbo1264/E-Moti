# 第十三批生命周期与旧案例回归：模型账户阻塞

第十三批数据 SHA256 为 7a30caf799c008d0ae5cf685b45c36472372bf676d789d4660c68c649b69fd2b，冻结后开始评测，未更改样本或生产。before 00f0d4f，after d3c55d2。所有真实请求均收到 HTTP 402，原始响应明确为：

`{"error":{"message":"Insufficient Balance (request_id: …)","type":"insufficient_balance_error","param":null,"code":"invalid_request_error"}}`

| 运行 | 尝试请求 | 成功模型响应 | 已记录 turn | 直接错误 / fallback |
| --- | ---: | ---: | ---: | ---: |
| thirteenth-lifecycle-before | 37 | 0 | 28 | 13 / 15 |
| thirteenth-lifecycle-after | 40 | 0 | 28 | 14 / 14 |
| legacy-lifecycle-after | 19 | 0 | 14 | 0 / 14 |

共 96 次请求，全部 HTTP 402，无任何成功模型输出或 provider token usage。这里的零 token 表示响应未提供 usage，不作为账单费用结论。尝试停止时进程已经结束，没有启动重试。

这些运行的模型回答验收标记为 **not_run / insufficient_balance**，不计算正确率、不提出新的泛化结论。旧 driver 在遍历结束时写入的 `status=completed` 仅表示控制流程结束，不能视为验收完成；本说明明确修正其解释。工具已补充遇首次 HTTP 402 即保存并终止后续场景，后续输出直接标 blocked。

旧教师/游泳案例有独立于模型的存储结果：本地解析仍保存教师姓名并更正为新值，遗忘后老师旧新值均撤回、用户自身姓名保留；每周游泳改期后旧时间退休，遗忘后旧新时间撤回、无关饮料偏好保留。两场存储修改和撤回均成立，但真实模型的重开回答与人格表现未运行，不能用 fallback 文本冒充通过。

全部 provider 原始错误、已保存的 prompt、各轮本地存储和检索 trace 在三个同名目录保留。由于第十三批输入已被运行和读取，后续恢复凭据后属于已见回归；新的独立泛化结论需要另行密封样本。
