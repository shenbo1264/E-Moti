# 第十一批生命周期首评

统一通过 DesktopDialogueService 原生入口逐轮输入，四场景各七轮。每条 new_conversation 都先清空短期历史，关闭服务及 controller，再打开同一个持久档案；属于同进程重开，不宣称进程重启。before 与 after 自身分别是独立评测进程。期望、phase 和答案从未送入生产提示。原始 provider prompt、输出、usage 在各目录 provider-calls.json；逐轮结果、完整存储及提交时检索 trace 在 results.json。

before 实际包为 memory-completion-baseline，commit 00f0d4f；after 为 memory-generalization，commit 4ce35c3（生产冻结 523150e）。没有对失败题重新抽样或改生产。

| 层级 | before | after |
| --- | ---: | ---: |
| 完成输入与回复 | 28/28 | 28/28 |
| 更正后清空历史重开召回正确 | 0/4 | 0/4 |
| 遗忘后回答披露禁用值 | 0/4 | 0/4 |
| 无关事实召回正确 | 2/4 | 1/4 |
| 仅按回答核对的十二题正确 | 6/12 | 5/12 |
| 表达 fallback 或 turn error | 0/28 | 0/28 |
| provider 请求 | 72 | 71 |
| 实际输入 token | 168524 | 162629 |
| 实际输出 token | 20560 | 33577 |
| 其中 reasoning token | 17901 | 30395 |
| 累计请求耗时 ms | 191201.44 | 272237.16 |

“遗忘后未披露”不能计为生命周期成功：before 四个目标从未有效持久保存；after 广播旧栏目与换杯事件在遗忘要求后仍未删除。全部 provider finish_reason=stop，但不等于所有抽取结果通过生产校验。

## 逐场景失败

- puzzle：两路物品位置自述、搬移均 ignored；清空历史重开后均不知道。饮料偏好保存并召回。遗忘命令因目标缺失 clarify。
- umbrella：两路颜色及壁纸均未保存；after 颜色更换为 clarify，before ignored。更正召回、壁纸召回均失败。遗忘轮 ignored，没有可验证的有效撤回。
- radio：before 原栏目 clarify，方格内页保存，换栏目 ignored。after 原栏目保存，但独立的方格内页被放入 pending；换栏目 clarify。两路当前栏目召回失败；after 无关内页也不能召回。after 遗忘后旧栏目仍为未删除有效记录，回答未泄漏不能代替撤回成功。
- travel_mug：before 容量、电脑名、更换都未保存。after 更换保存两个事件：换了 500 毫升保温杯为 completed；以后带去工作室为 planned。后者只有“这个”而缺具体杯子绑定。容量问题仍回答不知道，遗忘命令 clarify，两个事件都继续有效；电脑名未保存。

## 结论

这批独立数据没有证明通用生命周期改善。开放物品属性提取、偏好独立槽位、更正绑定、自然遗忘目标解析及事件到属性查询连接仍存在缺口。新增约定事件能力的小切片成功不能外推为这些能力已完成。样本从本次起为已见回归；后续改动不得继续将其称为密封泛化结论。
